Proyecto dot_developers

En el archivo se encuentran 6 archivos.
"creación tablas" hace referencia al codigo SQL encargado de la creación total de las tablas usadas en el proyecto.
"inserción datos" hacer referencia a la agregación de los datos con los que el programa parte
"diagrama basico SQL" Es un diagrama sin estructura fisica que muestra agrosomodo las relaciones de la base de datos
"documento": Se encuentra el documento del proyecto
"proyecto": es el archivo del codigo en java que corre el proyecto. Se encuentra como zip y es necesario descomprimirlo.


A tener en cuenta: A la hora de correr el codigo java e ingresar a la interfaz si se desea añadir, modificar o elminar un producto es necesario señalar el tipo de producto en las checkbox respectivas (y en la tabla de productos). Adicionalmente, la infromación se debe agregar en el apartado de producto y en el apartado del producto especifico con el que se esté realizando la modificacion.
Tambien es importante tener en cuenta que para hacer un cambio en el apartado pedido es necesario tener señalado el pedido a modificar en la tabla e ingresar los datos de la modificación antes de oprimir el botón.
Recordar que de querer correr una base de datos local es necesario dirigirse al apartado del codigo como 'sql -> conexionsql.java' y realizar las modificaciones en el url,user y password.

TENER EN CUENTA QUE EL PROYECTO FUE USADO POR MEDIO DE UNA BASE DE DATOS LOCAL DE TIPO POSTGRESQL.


cualquier inquietud escribir al siguiente correo: edwardduarte@javeriana.edu.co